package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

public class Airline {
    @SerializedName("name")
    private String name;
    @SerializedName("iataCode")
    private String iataCode;
    @SerializedName("icaoCode")
    private String icaoCode;

    public Airline() {
        this.name = "";
        this.iataCode = "";
        this.icaoCode = "";
    }

    public String getName() {
        return name;
    }

    public String getIataCode() {
        return iataCode;
    }

    public String getIcaoCode() {
        return icaoCode;
    }
}
