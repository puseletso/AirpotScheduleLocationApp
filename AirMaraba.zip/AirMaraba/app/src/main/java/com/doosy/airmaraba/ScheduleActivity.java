package com.doosy.airmaraba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.doosy.airmaraba.adapters.AdapterSchedule;
import com.doosy.airmaraba.model.Airport;
import com.doosy.airmaraba.model.AirportSchedule;
import com.doosy.airmaraba.utils.Globals;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScheduleActivity extends AppCompatActivity {

    private Airport mAirport;
    private final String bundleName = "airport";
    private RecyclerView recyclerViewSchedule;
    private ProgressBar progressBar;

    private AdapterSchedule mAdapterSchedule;

    private TextView tvAirportName;
    private TextView tvtAirportLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(getIntent() != null && getIntent().hasExtra(bundleName)){
            Bundle bundle = getIntent().getExtras();
            mAirport = (Airport) bundle.get(bundleName);

            if(!mAirport.getCodeIataAirport().isEmpty())
                getAirportSchedule(mAirport.getCodeIataAirport());
        }

        setContentView(R.layout.activity_main);
        init();
        displayLoad(true);
    }

    private void init() {
        recyclerViewSchedule = findViewById(R.id.recyclerViewSchedule);
        progressBar = findViewById(R.id.progressBar);
        tvAirportName = findViewById(R.id.tvAirportName);
        tvtAirportLocation = findViewById(R.id.tvtAirportLocation);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        recyclerViewSchedule.setLayoutManager(mLayoutManager);
        recyclerViewSchedule.setItemAnimator(new DefaultItemAnimator());
        recyclerViewSchedule.addItemDecoration(new DividerItemDecoration(getApplicationContext(),
                DividerItemDecoration.VERTICAL));
        recyclerViewSchedule.setNestedScrollingEnabled(false);
        tvAirportName.setText(mAirport.getNameAirport());
        tvtAirportLocation.setText(mAirport.getNameCountry());

    }

    private void displayLoad(boolean isLoading){
        recyclerViewSchedule.setVisibility(isLoading ? View.GONE : View.VISIBLE);
        progressBar.setVisibility(isLoading ? View.VISIBLE : View.GONE);
    }

    private void getAirportSchedule(String airportCode){

        Call<List<AirportSchedule>> response = Globals.AirportInter
                .getAirportSchedules(airportCode);

        response.enqueue(new Callback<List<AirportSchedule>>() {
            @Override
            public void onResponse(Call<List<AirportSchedule>> call,
                                   Response<List<AirportSchedule>> response) {

                if(response.isSuccessful()){
                    List<AirportSchedule> airportSchedule = response.body();
                    if(airportSchedule != null) {
                        displaySchedules(airportSchedule);
                    }
                }
                displayLoad(false);
            }

            @Override
            public void onFailure(Call<List<AirportSchedule>> call, Throwable t) {
                Log.d(Globals.TAG, call.toString());
                Log.d(Globals.TAG, t.toString());
                displayLoad(false);
                Toast.makeText(getApplicationContext(), "On Failure", Toast.LENGTH_LONG).show();
            }
        });

    }

    private void displaySchedules(List<AirportSchedule> airportSchedules) {

        mAdapterSchedule = new AdapterSchedule(this ,airportSchedules);
        recyclerViewSchedule.setAdapter(mAdapterSchedule);
    }

}
