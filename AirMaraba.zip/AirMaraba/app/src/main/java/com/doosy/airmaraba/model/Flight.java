package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

public class Flight {
    @SerializedName("number")
    private String number;
    @SerializedName("iataNumber")
    private String iataNumber;
    @SerializedName("icaoCode")
    private String icaoNumber;

    public Flight() {
        this.number = "";
        this.iataNumber = "";
        this.icaoNumber = "";
    }

    public String getNumber() {
        return number;
    }

    public String getIataNumber() {
        return iataNumber;
    }

    public String getIcaoNumber() {
        return icaoNumber;
    }
}
