package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Airport implements Serializable {
    @SerializedName("nameAirport")
    private String nameAirport;
    @SerializedName("nameCountry")
    private String nameCountry;
    @SerializedName("codeIataAirport")
    private String codeIataAirport;
    @SerializedName("codeIcaoAirport")
    private String codeIcaoAirport;
    @SerializedName("codeIso2Country")
    private String codeIso2Country;
    @SerializedName("codeIataCity")
    private String codeIataCity;
    @SerializedName("latitudeAirport")
    private double latitudeAirport;
    @SerializedName("longitudeAirport")
    private double longitudeAirport;
    @SerializedName("timezone")
    private String timezone;
    @SerializedName("GMT")
    private String GMT;
    @SerializedName("phone")
    private String phone;

    public Airport() {
        this.nameAirport = "";
        this.nameCountry = "";
        this.codeIataAirport = "";
        this.codeIcaoAirport = "";
        this.codeIso2Country = "";
        this.codeIataCity = "";
        this.latitudeAirport = 0.0;
        this.longitudeAirport = 0.0;
        this.timezone = "";
        this.GMT = "";
        this.phone = "";
    }

    public String getNameAirport() {
        return nameAirport;
    }

    public String getNameCountry() {
        return nameCountry;
    }

    public String getCodeIataAirport() {
        return codeIataAirport;
    }

    public String getCodeIcaoAirport() {
        return codeIcaoAirport;
    }

    public String getCodeIso2Country() {
        return codeIso2Country;
    }

    public String getCodeIataCity() {
        return codeIataCity;
    }

    public double getLatitudeAirport() {
        return latitudeAirport;
    }

    public double getLongitudeAirport() {
        return longitudeAirport;
    }

    public String getTimezone() {
        return timezone;
    }

    public String getGMT() {
        return GMT;
    }

    public String getPhone() {
        return phone;
    }
}
