package com.doosy.airmaraba.utils;

import com.doosy.airmaraba.model.Airport;
import com.doosy.airmaraba.model.AirportSchedule;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface AirportInterface {
    @GET("nearby?key=21e4f3-b80252&distance=100")
    Call<List<Airport>> getNearByAirport(@Query("lat") double lat, @Query("lng") double lng);

    @GET("timetable?key=e5ae3d-5ee94e&limit=100&type=departure")
    Call<List<AirportSchedule>> getAirportSchedules (@Query("iataCode") String code);

}
