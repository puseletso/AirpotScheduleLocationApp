package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

public class Departure {
    @SerializedName("iataCode")
    private String iataCode;
    @SerializedName("icaoCode")
    private String icaoCode;
    @SerializedName("terminal")
    private String terminal;
    @SerializedName("scheduledTime")
    private String scheduledTime;


    public Departure() {
        this.iataCode = "";
        this.icaoCode = "";
        this.terminal = "";
        this.scheduledTime = "";
    }

    public String getIataCode() {
        return iataCode;
    }

    public String getIcaoCode() {
        return icaoCode;
    }

    public String getTerminal() {
        return terminal;
    }

    public String getScheduledTime() {
        return scheduledTime;
    }
}
