package com.doosy.airmaraba.model;

import com.doosy.airmaraba.model.AirportSchedule;

import java.util.List;

public class ServerModel {

    private List<AirportSchedule> airportSchedule;

    public List<AirportSchedule> getAirportSchedule() {
        return airportSchedule;
    }
}
