package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

public class Arrival {
    @SerializedName("iataCode")
    private String iataCode;
    @SerializedName("icaoCode")
    private String icaoCode;
    @SerializedName("terminal")
    private String terminal;
    @SerializedName("scheduledTime")
    private String scheduledTime;
    @SerializedName("estimatedTime")
    private String estimatedTime;
    @SerializedName("actualTime")
    private String actualTime;
    @SerializedName("estimatedRunway")
    private String estimatedRunway;

    public Arrival() {
        this.iataCode = "";
        this.icaoCode = "";
        this.terminal = "";
        this.scheduledTime = "";
        this.estimatedTime = "";
        this.actualTime = "";
        this.estimatedRunway = "";
    }

    public String getIataCode() {
        return iataCode;
    }

    public String getIcaoCode() {
        return icaoCode;
    }

    public String getTerminal() {
        return terminal;
    }

    public String getScheduledTime() {
        return scheduledTime;
    }

    public String getEstimatedTime() {
        return estimatedTime;
    }

    public String getActualTime() {
        return actualTime;
    }

    public String getEstimatedRunway() {
        return estimatedRunway;
    }

}
