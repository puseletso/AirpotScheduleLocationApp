package com.doosy.airmaraba.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.doosy.airmaraba.R;
import com.doosy.airmaraba.model.AirportSchedule;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.List;




public class AdapterSchedule extends RecyclerView.Adapter<AdapterSchedule.MyViewHolderReview> {
    private List<AirportSchedule> airportSchedules;
    private Context mContext;

    @Override
    public MyViewHolderReview onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.schedule_row, parent, false);

        return new MyViewHolderReview(itemView);
    }

    private String formatTime(DateTime dt){
        int hour = dt.getHourOfDay();
        int min = dt.getMinuteOfHour();


        String formattedHour = (hour < 10) ? "0" + hour :  String.valueOf(hour);
        String formattedMin = (min < 10) ? "0" + min :  String.valueOf(min);

        return  formattedHour + ":" + formattedMin;
    }


    @Override
    public void onBindViewHolder(final MyViewHolderReview holder, final int position) {
        final AirportSchedule schedule = airportSchedules.get(position);

        if(schedule.getStatus() != null){
            boolean hasDeparted = schedule.getStatus().equals("landed");
            if( hasDeparted ) {
                holder.imageStatus.setImageResource(R.drawable.red_dot_x2);
                holder.tvScheduleType.setText("Departed");
            }
            else {
                holder.imageStatus.setImageResource(R.drawable.green_dot_x2);
                holder.tvScheduleType.setText("Boarding");
            }
        }else{
            holder.imageStatus.setImageResource(R.drawable.red_dot_x2);
            holder.tvScheduleType.setText("None");
        }

        //holder.imageStatus;
        if(schedule.getCodeshared() != null && schedule.getCodeshared().getAirline() != null) {
            holder.tvAirportName.setText(schedule.getCodeshared().getAirline().getName());
        }else{
            holder.tvAirportName.setText("None");
        }


        if(schedule.getDeparture() != null) {

            String date = "--:--";
            if(schedule.getDeparture().getScheduledTime() != null){

                DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
                DateTime dt = formatter.parseDateTime(schedule.getDeparture().getScheduledTime());

                date = formatTime(dt);
            }

            holder.tvDepartTime.setText(date);
        }else{
            holder.tvDepartTime.setText("None");
        }

        if(schedule.getFlight() != null) {
            holder.tvFlightNumber.setText(schedule.getFlight().getIataNumber());
        }else {
            holder.tvFlightNumber.setText("None");
        }

        if(schedule.getCodeshared() != null && schedule.getCodeshared().getAirline() != null){
            holder.tvDestination.setText(schedule.getCodeshared().getAirline().getIataCode());
        }else{
            holder.tvDestination.setText("None");
        }
    }

    @Override
    public int getItemCount() {
        return airportSchedules.size();
    }

    public AdapterSchedule(Context mContext, List<AirportSchedule> airportSchedules) {
        this.airportSchedules = airportSchedules;
        this.mContext = mContext;
    }

    public class MyViewHolderReview extends RecyclerView.ViewHolder{

        ImageView imageStatus;
        TextView tvAirportName;
        TextView tvScheduleType;
        TextView tvDepartTime;
        TextView tvFlightNumber;
        TextView tvDestination;


        public MyViewHolderReview(View view) {
            super(view);
            imageStatus = view.findViewById(R.id.imgStatus);
            tvAirportName = view.findViewById(R.id.tvAirportName);
            tvScheduleType = view.findViewById(R.id.tvScheduleType);
            tvDepartTime = view.findViewById(R.id.tvDepartTime);
            tvFlightNumber = view.findViewById(R.id.tvFlightNumber);
            tvDestination = view.findViewById(R.id.tvDestination);
        }

    }
}
