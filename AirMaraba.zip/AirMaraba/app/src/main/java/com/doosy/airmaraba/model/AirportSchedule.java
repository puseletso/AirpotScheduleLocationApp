package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class AirportSchedule implements Serializable {
    @SerializedName("type")
    private String type;
    @SerializedName("status")
    private String status;
    @SerializedName("departure")
    private Departure departure;
    @SerializedName("arrival")
    private Arrival arrival;
    @SerializedName("airline")
    private Airline airline;
    @SerializedName("flight")
    private Flight flight;
    @SerializedName("codeshared")
    private Codeshared codeshared;


    public AirportSchedule() {
        this.type = "";
        this.status = "";
    }

    public String getType() {
        return type;
    }

    public String getStatus() {
        return status;
    }

    public Departure getDeparture() {
        return departure;
    }

    public Arrival getArrival() {
        return arrival;
    }

    public Airline getAirline() {
        return airline;
    }

    public Flight getFlight() {
        return flight;
    }

    public Codeshared getCodeshared() {
        return codeshared;
    }
}
