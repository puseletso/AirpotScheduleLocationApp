package com.doosy.airmaraba.model;

import com.google.gson.annotations.SerializedName;

public class Codeshared {

    @SerializedName("airline")
    private Airline airline;
    @SerializedName("flight")
    private Flight flight;


    public Airline getAirline() {
        return airline;
    }

    public Flight getFlight() {
        return flight;
    }
}
